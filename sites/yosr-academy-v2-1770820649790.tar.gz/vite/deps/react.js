import {
  require_react
} from "./chunk-QDX3DHTH.js";
export default require_react();
