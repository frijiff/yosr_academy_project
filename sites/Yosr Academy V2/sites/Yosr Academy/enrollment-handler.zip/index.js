/* Enrollment Handler Appwrite Function
   - Reads payload from APPWRITE_FUNCTION_DATA (JSON string)
   - Validates fields and inserts a row into the tables-db via REST
*/

const endpoint = process.env._APPWRITE_FUNCTION_ENDPOINT || 'https://cloud.appwrite.io/v1';
const projectId = process.env._APPWRITE_FUNCTION_PROJECT_ID || process.env.APPWRITE_PROJECT_ID || '69852cb4003496ea2e8d';
const apiKey = process.env.APPWRITE_API_KEY; // project secret variable (set as project variable)

(async () => {
  try {
    const raw = process.env.APPWRITE_FUNCTION_DATA || '{}';
    const payload = JSON.parse(raw);

    const parentName = (payload.parentName || '').toString().trim();
    const phone = (payload.phone || '').toString().trim();
    const children = payload.children || [];

    if (!parentName || !phone || !Array.isArray(children) || children.length === 0) {
      console.error('Validation failed', { parentName, phone, children });
      process.stdout.write(JSON.stringify({ success: false, message: 'Validation failed' }));
      process.exit(1);
    }

    const body = {
      parentName,
      phone,
      children: JSON.stringify(children),
      status: 'pending',
      submittedAt: new Date().toISOString()
    };

    const res = await fetch(`${endpoint}/databases/enrollment-db/tables/enrollments/rows`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Appwrite-Project': projectId,
        'X-Appwrite-Key': apiKey
      },
      body: JSON.stringify(body)
    });

    const json = await res.json();

    if (!res.ok) {
      console.error('Upsert failed', json);
      process.stdout.write(JSON.stringify({ success: false, error: json }));
      process.exit(1);
    }

    console.log('Row created', json);
    process.stdout.write(JSON.stringify({ success: true, row: json }));
    process.exit(0);
  } catch (err) {
    console.error('Function error', err);
    process.stdout.write(JSON.stringify({ success: false, error: err.message || err }));
    process.exit(1);
  }
})();